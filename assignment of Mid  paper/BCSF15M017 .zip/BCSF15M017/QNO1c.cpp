/*Muhammad Azam
BCSF15M017 */
#include <iostream>
using namespace std;
void main ()
{
	int i = 1 , j = 2, k = 3 , m = 2;
	if ( i == 1 )
	cout << "a is true" << endl;
	if ( j == 3 )
	cout << "b is true" << endl;
	if ( m <= 99 && k < m )
	cout << "c is true" << endl;
	if ( j >= i || k == m )
	cout << "d is true" << endl;
	if ( k + m < j || 3 - j >= k )
	cout << "e is true" << endl;
	if ( !( k > m ) )
	cout << "f is true" << endl;
	system ("pause ");
}