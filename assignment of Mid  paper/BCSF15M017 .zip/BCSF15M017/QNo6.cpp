/*Muhammad Azam
BCSF15M017 */
#include<iostream >
using namespace std ;
int main ()
{
	int a, b, c, d, ans1,ans2;
	char op ,ch;
	do
	{
		cout << "Enter numerator for first fraction: ";
		cin >>a ;
		cout <<"Enter denominator for first fraction: ";
		cin>> b;
		do 
		{
			cout <<"Enter Operator:";
			cin>> op;	
		}while(!(op=='+' || op=='-'|| op=='/'||op=='*')); 
		cout <<"Enter numerator for second fraction: ";
		cin>> c;
		cout <<"Enter denominator for second fraction: ";
		cin>>d;
		switch(op)
		{
		case '+':
			ans1=(a*d + b*c) ;
			ans2=(b*d);
			break;
		case'-':
			ans1=(a*d - b*c) ;
			ans2=(b*d);
			break;
		case '*':
			ans1=(a*c) ;
			ans2=(b*d);
			break;
		case '/':
			
			ans1=(a*d) ;
			ans2=(b*c);
		}
		cout << "\nPress any key to continue and  N for No : ";
		cout << a<<"/"<<b<<op<<c<<"/"<<d <<" = "<< ans1 <<"/"<<ans2;
		cin>> ch;
	}while (!(ch=='n' || ch=='N'));
}
