/*Muhammad Azam
BCSF15M017 */
#include <iostream >
using namespace std ;
void main ()
{
	int l=1,totalLines=5 , numb=1,tSpaces=totalLines,i ;
	char ch='A';
	while (l<=totalLines)
	{
		i=1 ;
		while (i <tSpaces )
		{
			cout <<"\t";
			i++;
		}
		i=1;
		if(l%2==0)
		{
			while (i<=l)
			{
				cout << ch++<<"\t";
				i++;
			}
		}
		else 
		{
			while (i<=l)
			{
				cout <<numb++<<"\t";
				i++;
			}
		}
		l++;
		cout<<endl;
		tSpaces--;
	}
}