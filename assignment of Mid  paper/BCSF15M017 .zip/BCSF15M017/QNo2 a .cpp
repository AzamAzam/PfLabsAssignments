/*Muhammad Azam
BCSF15M017 */
#include <iostream >
using namespace std ;
void main ()
{
	int age ;
	cin >> age;
	if (age<=17 || age>=25)
	cout << "invalid age" <<endl;
	system ("pause ");
}