/*Muhammad Azam
BCSF15M017 */
#include <iostream >
using namespace std ;
void main ()
{

	int num=0, n = 1, sum = 0;
	cout <<"Enter a number until which you want to see sum of odd numbers: ";
	cin>>num;
	while (n<=num)
	{
	sum = sum + n;
	n = n + 2;
	}
	cout << sum<<endl;
	system ("pause ");
}