/*Muhammad Azam
BCSF15M017 */
#include <iostream >
using namespace std ;
void main ()
{
	int i, number, sum=0 ;
	cout << " Enter a number to check wheter it is divisible of 9 & 3 or Not : ";
	cin>> number ;
	i =number ;
	while (i!=0)
	{
		sum = sum  +i%10;
		i=i/10;
	}
	if (sum % 9==0)
		cout << "It is divisible by  9 and 3 ";
	else if (sum % 3 == 0)
		cout << "It is divisible by 3 ";
	else 
		cout << "It is not Divible By 9 or 3 ";
	cout <<"\n";
	system ("pause ");
}