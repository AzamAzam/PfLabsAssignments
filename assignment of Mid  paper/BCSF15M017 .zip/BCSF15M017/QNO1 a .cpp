/*Muhammad Azam
BCSF15M017 */
#include <iostream>
using namespace std;
void main ()
{
	int sum , num , j; 
	cin>>sum;
	cin >> num;
	j=1;
	while (j <= 3)
	{
	cin >> num;
	sum = sum + num;
	j = j+1;
	}
	cout << "Sum = " << sum << endl;
	system ("pause ");
}