//#include <iostream>
//using namespace std ;
//void main ()
//
//{
//	int i,count ;
//	char character, str[50];
//	cout << "Enter A string to count vowels : ";
//	cin.getline (str,49);
//	str[49]='\0';
//	count =0;
//	for (i=0;str[i]!='\0';i++)
//	{
//		if (str[i]=='A' || str[i]=='a' || str[i]=='E' || str[i]=='e' || str[i]=='I' || str[i]=='i' || str[i]=='O' || str[i]=='o' || str[i]=='U' || str[i]=='u')	
//			count ++;
//	}
//	cout <<"Voweles are in given string : "<<count <<endl;
//
//}