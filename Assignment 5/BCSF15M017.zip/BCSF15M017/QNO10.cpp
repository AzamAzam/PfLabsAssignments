//#include <iostream>
//using namespace std ;
//void main ()
//{
//	int i;
//	char date[11];
//	cout << "ENter date in format mm/dd/yyyy :";
//	cin >> date ;
//	cout << "Formated Date :\n";
//	if (date[0]=='0'&& date[1]=='1')
//		cout <<"January ";
//	else if (date[0]=='0'&& date[1]=='2')
//		cout <<"February ";
//	else if (date[0]=='0'&& date[1]=='3')
//		cout <<"March ";
//	else if (date[0]=='0'&& date[1]=='4')
//		cout <<"April ";
//	else if (date[0]=='0'&& date[1]=='5')
//		cout <<"May ";
//	else if (date[0]=='0'&& date[1]=='6')
//		cout <<"June ";
//	else if (date[0]=='0'&& date[1]=='7')
//		cout <<"July ";
//	else if (date[0]=='0'&& date[1]=='8')
//		cout <<"August ";
//	else if (date[0]=='0'&& date[1]=='9')
//		cout <<"September ";
//	else if (date[0]=='1'&& date[1]=='0')
//		cout <<"October ";
//	else if (date[0]=='1'&& date[1]=='1')
//		cout <<"November ";
//	else if (date[0]=='1'&& date[1]=='2')
//		cout <<"December ";
//	else 
//		cout <<"YOu entered a wrong Month Number : ";
//	if ((date [0]=='0'||date[0]=='1')&&(date[1]=='0'||date[1]=='1'||date[1]=='2'))			//wrong month input will not show date  
//	for (i=3;date[i]!='\0';i++)
//	{
//		if (date[i]=='/')
//			cout <<", ";
//		else 
//			cout <<date[i];
//	}
//	cout <<endl; 
//
//}
//
