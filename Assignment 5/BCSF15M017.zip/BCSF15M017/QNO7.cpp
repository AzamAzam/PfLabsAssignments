//#include <iostream>
//#include <conio.h>
//using namespace std ;
//void main ()
//
//{
//	int i,j;
//	char character, str1[50],str2[50];
//	cout <<"Eneter a string :";
//	cin .getline (str1,49);
//	str1 [49]='\0';
//	cout << "Enter a character to remove from th string :";
//	character=getche();
//	for (i=0,j=0;str1[i]!=NULL ;i++)
//	{
//			if (character !=str1[i])
//				str2[j++]=str1[i];
//	}
//	str2[j]='\0';
//	cout <<endl<<"processed string  "<< str2 <<endl;
//
//	system("pause");
//
//}
