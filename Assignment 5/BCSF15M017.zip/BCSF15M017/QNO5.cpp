//#include <iostream>
//using namespace std;
//void main ()
//{
//	int i,j=0;
//	char str1[500],str2[100];
//	cout << "Enter first string :";
//	cin.getline (str1,399);
//	str1[399]='\0';
//	cout <<"Enter second string to concatenate :";
//	cin.getline (str2,100);
//	str2[99]='\0';
//	for (i=0;str1[i]!='\0';i++);		// to calculate length of 1st string 
//
//	for (i;str2[j]!='\0';i++)
//	{
//		str1[i]=str2[j++];
//	}
//	str1[i]='\0';
//	cout <<  str1<<endl;
//
//}
