//#include<iostream>
//using namespace std;
//void main ()
//{
//	int i,j,length ;
//	char str[50];
//	cout <<"Enter a string to check palindrom  :";
//	cin.getline (str,49);
//	str[49]='\0';
//	length =0;
//	for (i=0;str[i]!='\0';i++)      // to calculate length of string 
//	{
//		length ++;
//	}
//	for (i=0;i<length/2 ;i++)
//	{
//		if (str[i]!=str[length-i-1])
//			break;
//	}
//	if (i==length/2)											
//		cout << "It is palindrom ";
//	else 
//		cout << "It is not a palindrom";
//	cout << endl;
//	
//
//}
