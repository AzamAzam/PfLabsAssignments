//#include <iostream >
//using namespace std ;
//void main ()
//{
//	int i,count=1;
//	char str[100];
//	cout <<" Enter a string to count words :";
//	cin.getline (str,99);
//	str[99]=='\0';
//	for (i=0;str[i]!='\0';i++)
//	{
//		if (str[i]==' ' && str[i+1]!=' '&& str[i+1]!='\0')				//increment in count will be if after space is a character
//			count ++;
//	}
//	cout <<"words are in this sentence : "<< count <<endl;
//
//}
