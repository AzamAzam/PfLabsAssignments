//problem is here 
#include <iostream>
using namespace std;
void main ()
{
	int i,flag=200,number [11]={0};
	int total , n ,gross[100];
	cout <<"Enter the Number of employees :";
	cin >>n;
	for (i=1;i<=n;i++)
	{
		cout << "Enter gross sales  :";
		cin>> gross [i];
		total =200+(0.09*gross[i]);
		if (total>=200 && total<300 )
			number [1]++;
		else 	if (total>=300 && total<400 )
			number [2]++;
		else	if (total>=400 && total<500 )
			number [3]++;
		else if (total>=500 && total<600 )
			number [4]++;
		else if (total>=600 && total<700 )
			number [5]++;
		else if (total>=700 && total<800 )
			number [6]++;
		else if (total>=800 && total<900 )
			number [7]++;
		else if (total>=900 && total<1000 )
			number [8]++;
		else if (total>1000)
			number [9]++;
		else 
		number [10]++;
	}
	 for(i=1;i<9;i++)
	 {
		 cout << "Between $"<< flag ;
		 flag=flag+100;
		 cout << "and $"<< flag-1 << " are : "<< number[i];
		 cout<< endl;

	 }
	 cout <<"greater than $1000 are : "<<number [i++]<<endl; 
	 cout << "you entered Wrong value (less than 200) : "<<number [i]<<endl;


	 
}