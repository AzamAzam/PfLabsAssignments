//#include<iostream>
//using namespace std;
//main ()
//{
//	double alpha[50];
//	int i;
//	for (i=0;i<25;i++)
//	{
//		alpha [i]= i*i;
//		
//	}
//	for (i;i<50;i++)
//	{
//		alpha [i]= 3*i;
//		
//	}
//	for (i=0;i<50;i++)
//	{
//		cout << alpha [i]<<",\t";
//		if ((i+1)%10==0)
//		cout <<endl;
//		
//	}
//	
//	
//cout<< "\n";
//system("pause");
//}
//
