//#include<iostream>
//#include <cmath>
//using namespace std;
//void main ()
//{
//	int i,j,n,index=1, number[1000]; 
//	cout << "Enter a limiting value  ";
//	cin >> n ;
//	cout << "_________________________________________\nN\t|n^2\t|N^3\t|n^5\t|N^7\t| \n";
//	for (i=1;i<=n ;i++)
//	{
//		number[index++]=i;
//		for (j=2;j<=7;j++)
//		{
//			number[index++]=pow(i,j);
//			if (j>2)
//				j++;
//		}
//	 } 
//	cout << "_________________________________________\n"; 
//	for (i=1 ;i <index ;i++)
//	{
//		cout << number[i]<<"\t|";
//		if (i%5==0)
//		cout << "\n_________________________________________\n";
//
//	}
//	cout<< "\n";
//system("pause");
//}
//
