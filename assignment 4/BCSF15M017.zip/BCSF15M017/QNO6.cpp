//#include <iostream>
//using namespace std;
//void main ()
//{
//	float sum=0 ,mean , number[100], deviation,variable=0;
//	int i,n;
//	cout << "How many numbers Ypu want to enter ";
//	cin >>n;
//	cout <<"Enter values " ;
//	for(i=0;i<n;i++)
//	{
//		cin>> number [i];
//		sum=sum+number[i];
//	}
//	mean =sum/n;
//	for (i=0;i<n;i++)
//		variable =variable + (number[i]-mean)*(number[i]-mean);
//	deviation=sqrt(variable/n);
//	cout << "mean = "<<mean << "\nstandard deviation = "<<deviation<<endl;
//
//}
